<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content'); ?>
   <section>
<div class="container">
    <div class="row">
        <h1>Hi, Your successfully Log in</h1>
    </div>
</div>    
</section> 
<?php $__env->stopSection(); ?>
   
 
    


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\my work for online\filesupload\resources\views/contact.blade.php ENDPATH**/ ?>