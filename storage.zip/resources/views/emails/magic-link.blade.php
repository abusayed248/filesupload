<!DOCTYPE html>
<html>
<head>
    <title>Magic Login Link</title>
</head>
<body>
    <p>Hello,</p>
    <p>Click the link below to log in to your account:</p>
    <p><a href="{{ $link }}">{{ $link }}</a></p>
    <p>This link is valid for 30 minutes.</p>
</body>
</html>
